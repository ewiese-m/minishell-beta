/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ewiese-m <ewiese-m@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/28 21:30:00 by ewiese-m          #+#    #+#             */
/*   Updated: 2025/03/30 17:37:10 by ewiese-m         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/minishell.h"

t_minishell	g_minishell;

static void	setup_signals(void)
{
	signal(SIGINT, ft_signal_ctrl_c);
	signal(SIGQUIT, SIG_IGN);
	rl_catch_signals = 0;
}

static void	process_command(char *line, t_env *env_list)
{
	t_command	*cmds;
	int			exit_status;

	if (!line || *line == '\0')
		return ;
	add_history(line);
	cmds = ft_parse_input(line, env_list);
	if (cmds)
	{
		exit_status = execute_commands(cmds, env_list);
		update_exit_status(env_list, exit_status);
		ft_free_cmdlist(&cmds);
	}
	free(line);
}

static void	cleanup_resources(t_env *env_list)
{
	t_env	*current;
	t_env	*next;

	current = env_list;
	while (current)
	{
		next = current->next;
		if (current->key)
			free(current->key);
		if (current->value)
			free(current->value);
		free(current);
		current = next;
	}
	clear_history();
}

static void	minishell_loop(t_env *env_list)
{
	char	*line;

	while (1)
	{
		g_minishell.signal = 0;
		line = readline("minishell> ");
		if (!line)
		{
			printf("exit\n");
			break ;
		}
		process_command(line, env_list);
	}
}

int	main(int argc, char **argv, char **envp)
{
	t_env *env_list;

	(void)argc;
	(void)argv;
	g_minishell.force_exit = false;
	g_minishell.heredoc = false;
	g_minishell.signal = 0;
	setup_signals();
	env_list = ft_get_envp(envp);
	if (!env_list)
	{
		fprintf(stderr, "Error: Failed to initialize environment\n");
		return (1);
	}
	g_minishell.envs = env_list;
	minishell_loop(env_list);
	cleanup_resources(env_list);
	return (0);
}
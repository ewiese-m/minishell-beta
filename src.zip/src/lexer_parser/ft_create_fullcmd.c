/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_create_fullcmd.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ewiese-m <ewiese-m@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/28 20:18:20 by ewiese-m          #+#    #+#             */
/*   Updated: 2025/03/30 19:41:10 by ewiese-m         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../../includes/minishell.h"

void	ft_create_fullcmd(t_command *cmd)
{
	int	arg_count;
	int	i;

	while (cmd)
	{
		if (!cmd->command)
		{
			cmd = cmd->next;
			continue ;
		}
		arg_count = 0;
		while (cmd->args && cmd->args[arg_count])
			arg_count++;
		cmd->full_cmd = (char **)ft_calloc(arg_count + 2, sizeof(char *));
		if (!cmd->full_cmd)
		{
			cmd = cmd->next;
			continue ;
		}
		cmd->full_cmd[0] = ft_strdup(cmd->command);
		i = 0;
		while (i < arg_count)
		{
			cmd->full_cmd[1 + i] = ft_strdup(cmd->args[i]);
			i++;
		}
		cmd->full_cmd[1 + i] = NULL;
		if (cmd->next)
			cmd = cmd->next;
		else
			break ;
	}
}

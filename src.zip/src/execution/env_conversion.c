/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   env_conversion.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: ewiese-m <ewiese-m@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/27 14:11:01 by ewiese-m          #+#    #+#             */
/*   Updated: 2025/03/30 18:35:33 by ewiese-m         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/minishell.h"

/**
 * Counts the number of environment variables that should be exported
 */
static int	count_env_vars(t_env *env_list)
{
	int		count;
	t_env	*current;

	count = 0;
	current = env_list;
	while (current)
	{
		if (current->key[0] != '?' && current->value)
			count++;
		current = current->next;
	}
	return (count);
}

/**
 * Creates a new environment variable string
 */
static char	*create_env_string(t_env *current)
{
	char	*tmp;
	char	*result;

	tmp = ft_strjoin(current->key, "=");
	result = ft_strjoin(tmp, current->value);
	free(tmp);
	return (result);
}

/**
 * Creates and populates the environment array from the list
 */
static int	populate_env_array(char **env_array, t_env *env_list)
{
	int		i;
	t_env	*current;

	i = 0;
	current = env_list;
	while (current)
	{
		if (current->key[0] != '?' && current->value)
		{
			env_array[i] = create_env_string(current);
			if (!env_array[i])
			{
				free_env_array(env_array);
				return (-1);
			}
			i++;
		}
		current = current->next;
	}
	env_array[i] = NULL;
	return (0);
}

/**
 * Converts environment list to array
 */
char	**env_list_to_array(t_env *env_list)
{
	int		count;
	char	**env_array;
	int		status;

	count = count_env_vars(env_list);
	env_array = (char **)malloc(sizeof(char *) * (count + 1));
	if (!env_array)
		return (NULL);
	status = populate_env_array(env_array, env_list);
	if (status == -1)
		return (NULL);
	return (env_array);
}

/**
 * Frees the environment array
 */
void	free_env_array(char **env_array)
{
	int	i;

	if (!env_array)
		return ;
	i = 0;
	while (env_array[i])
	{
		free(env_array[i]);
		i++;
	}
	free(env_array);
}
